import "./components/Book.css";
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { collection, addDoc } from "firebase/firestore";
import { getFirestore } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCr9Y1YZca5eoEMI69o1VcMpw74PEYH3ww",
  authDomain: "bussticketapp.firebaseapp.com",
  projectId: "bussticketapp",
  storageBucket: "bussticketapp.appspot.com",
  messagingSenderId: "79830776119",
  appId: "1:79830776119:web:feace03101cd48abac82b2",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
let Bus = [
  {
    name: "Islamabad",
    to: "Karachi",
    price: "200",
    image:
      "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },

  {
    name: "Lahore",
    to: "Islamabad",
    price: "150",
    image:
      "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
  {
    name: "Sialkot",
    to: "Faisalabad",
    price: "120",
    image:
      "https://images.unsplash.com/photo-1570125909517-53cb21c89ff2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
  {
    name: "BaniGala",
    to: "Multan",
    price: "140",
    image:
      "https://images.unsplash.com/photo-1564694202883-46e7448c1b26?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
];

const Book = () => {
  const navigate = useNavigate();
  const bookBus = (item) => {
    console.log(item);
    // const imageTarget = document.querySelector("#targetImage");
    // const nameTarget = document.querySelector("#targetName");
    // const priceTarget = document.querySelector("#targetPrice");
    // const cards = document.querySelector(".cards_box");
    // const request = document.querySelector(".request");

    // imageTarget.src = item.image;
    // nameTarget.innerHTML = item.name;
    // priceTarget.innerHTML = "$" + item.price;
    // cards.style.display = "none";
    // request.style.display = "block";

    writeUserData(item);
  };
  async function writeUserData(item) {
    // navigate("/");
    // const users = window.localStorage.getItem("users");
    // const user = JSON.parse(users);

    // if (user.phone) {
    //   const docRef = await addDoc(collection(db, "booking"), {
    //     BusImage: item.image,
    //     BusName: item.name,
    //     BusPrice: "$" + item.price,
    //     BusDestination: item.to,
    //     phone: user.phone,
    //   });
    //   console.log(docRef);
    navigate(`/book/${item.name}/${item.price}/${item.to}`);
    // } else {
    // }
  }
  const request = (event) => {
    console.log(event);
    const imageTarget = document.querySelector("#targetImage");
    const nameTarget = document.querySelector("#targetName");
    const priceTarget = document.querySelector("#targetPrice");
    const request = document.querySelector(".request");
    const cards = document.querySelector(".cards_box");
    request.style.display = "none";
    cards.style.display = "block";
    alert("Your request has been sent");

    imageTarget.src = "";
    nameTarget.innerHTML = "";
    priceTarget.innerHTML = "";
  };
  console.log(Bus);
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div className="box">
        <div className="content">
          <div className="text">Find best Bus</div>
          <div className="target">
            <div className="trgt">
              <div className="card">
                <img
                  src="images.jpg"
                  id="targetImage"
                  alt=""
                  style={{
                    width: "10%",
                    height: "10%",
                  }}
                />
                <div className="hotel_name" id="targetName"></div>
                <div className="price" id="targetPrice"></div>
              </div>
            </div>
          </div>
          <div className="cards">
            <div className="cards_box">
              {Bus.map((item, index) => (
                <div className="card" key={index}>
                  <img src={item.image} alt="hotel1" />
                  <div className="hotel_name">
                    {item.name} to {item.to}
                  </div>
                  <div className="price">{"$" + item.price}</div>
                  <div className="request">
                    <button className="btn" onClick={() => bookBus(item)}>
                      Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
            {/* <div className="request">
            <button className="btn" onClick={request}>
            Request
            </button>
          </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Book;
